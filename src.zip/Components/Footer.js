import React from 'react';

function Footer(props) {
  return (
    <>
      <footer>
        <address>
          copyright &copy;2023 CGV 아트하우스 allrights reserved.
        </address>
      </footer>
    </>
  );
}

export default Footer;