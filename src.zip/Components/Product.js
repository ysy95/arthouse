import React from 'react';

function Product({moviedummy, movie, onRemove}) {
  return (
    <>
      <li>
        <img src={`${process.env.PUBLIC_URL}/img/${movie.img_name}`} alt="영화이미지" className='img'/>
      </li>
      <p>영화명 : {movie.m_name}</p>
      <p>개봉일 : {movie.date}</p>
      <p><button className='delete' onClick={()=>onRemove(moviedummy.movie.id)} >삭제</button>
      </p>
    </>
  );
}

export default Product;