import React from 'react';
import Header from './Header';
import Product from './ProductList';
import Footer from './Footer';
import './css/Common.css';


function App() {
  return (
    <>
    <Header/>
    <Product/>
    <Footer/>
    </>
  );
}

export default App;